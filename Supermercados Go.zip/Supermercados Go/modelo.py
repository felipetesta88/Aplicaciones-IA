"""
ANÁLISIS DE INVENTARIO Y PREDICCIÓN DE VENTAS - SUPERMERCADO GO
Versión optimizada con datos más realistas y mejores prácticas
"""

import pandas as pd
import numpy as np
import matplotlib.pyplot as plt
import seaborn as sns
import warnings
warnings.filterwarnings('ignore')

from sklearn.model_selection import train_test_split, cross_val_score, GridSearchCV
from sklearn.preprocessing import StandardScaler, MinMaxScaler
from sklearn.linear_model import LinearRegression
from sklearn.ensemble import RandomForestRegressor, GradientBoostingRegressor
from sklearn.cluster import KMeans, DBSCAN
from sklearn.metrics import mean_absolute_error, mean_squared_error, silhouette_score, r2_score
from sklearn.decomposition import PCA
from sklearn.impute import SimpleImputer
from scipy import stats
import matplotlib.cm as cm

# Configuración de estilo
plt.style.use('seaborn-v0_8-darkgrid')
sns.set_palette("husl")
plt.rcParams['figure.figsize'] = (12, 8)
plt.rcParams['font.size'] = 11

# =============================================
# CONFIGURACIÓN DE PARÁMETROS
# =============================================

class Config:
    """Clase de configuración para el proyecto"""
    SEED = 42
    N_PRODUCTOS = 20
    N_MUESTRAS = 1000  # Más muestras para mejor estadística
    TEST_SIZE = 0.2
    N_CLUSTERS_MIN = 2
    N_CLUSTERS_MAX = 10
    
    # Parámetros realistas de supermercado
    ROTACION_BAJA = 8    # veces/año (productos de lujo)
    ROTACION_MEDIA = 15  # veces/año (productos normales)
    ROTACION_ALTA = 30   # veces/año (productos frescos)
    
    STOCK_MINIMO_DIAS = 3
    STOCK_MAXIMO_DIAS = 30

# =============================================
# CATÁLOGO DE PRODUCTOS REALISTA
# =============================================

catalogo_productos = {
    1: {"nombre": "Pan corriente", "categoria": "panaderia", "perecible": True},
    2: {"nombre": "Leche entera", "categoria": "lacteos", "perecible": True},
    3: {"nombre": "Arroz", "categoria": "granos", "perecible": False},
    4: {"nombre": "Fideos", "categoria": "granos", "perecible": False},
    5: {"nombre": "Aceite vegetal", "categoria": "aceites", "perecible": False},
    6: {"nombre": "Azúcar", "categoria": "endulzantes", "perecible": False},
    7: {"nombre": "Huevos", "categoria": "lacteos", "perecible": True},
    8: {"nombre": "Pollo fresco", "categoria": "carnes", "perecible": True},
    9: {"nombre": "Carne vacuno", "categoria": "carnes", "perecible": True},
    10: {"nombre": "Verduras mixtas", "categoria": "verduras", "perecible": True},
    11: {"nombre": "Frutas de estación", "categoria": "frutas", "perecible": True},
    12: {"nombre": "Yogurt", "categoria": "lacteos", "perecible": True},
    13: {"nombre": "Queso", "categoria": "lacteos", "perecible": True},
    14: {"nombre": "Bebidas", "categoria": "bebidas", "perecible": False},
    15: {"nombre": "Agua mineral", "categoria": "bebidas", "perecible": False},
    16: {"nombre": "Productos congelados", "categoria": "congelados", "perecible": True},
    17: {"nombre": "Aseo hogar", "categoria": "limpieza", "perecible": False},
    18: {"nombre": "Higiene personal", "categoria": "higiene", "perecible": False},
    19: {"nombre": "Snacks", "categoria": "snacks", "perecible": False},
    20: {"nombre": "Panadería premium", "categoria": "panaderia", "perecible": True}
}

# =============================================
# GENERACIÓN DE DATOS MÁS REALISTA
# =============================================

def generar_datos_realistas(n_samples=Config.N_MUESTRAS):
    """
    Genera datos sintéticos realistas para supermercado
    con distribuciones Pareto (80/20) y relaciones económicas reales
    """
    np.random.seed(Config.SEED)
    
    # 1. Crear estructura temporal (365 días de datos)
    fechas = pd.date_range(start='2023-01-01', periods=n_samples, freq='D')
    
    data = pd.DataFrame({
        'fecha': fechas,
        'dia_semana': fechas.dayofweek + 1,  # 1=Lunes, 7=Domingo
        'mes': fechas.month,
        'semana_ano': fechas.isocalendar().week,
    })
    
    # 2. Distribución 80/20 de productos (Pareto)
    # 20% de productos generan 80% de las ventas
    product_weights = np.random.pareto(1.16, Config.N_PRODUCTOS)
    product_weights = product_weights / product_weights.sum()
    
    # Asignar productos según distribución Pareto
    data['producto_id'] = np.random.choice(
        range(1, Config.N_PRODUCTOS + 1), 
        size=n_samples, 
        p=product_weights
    )
    
    # 3. Características base por producto
    precios_base = {}
    ventas_base = {}
    rotacion_base = {}
    
    for pid in range(1, Config.N_PRODUCTOS + 1):
        producto_info = catalogo_productos[pid]
        
        # Precios según categoría (más realistas)
        if producto_info["categoria"] in ["panaderia", "lacteos", "verduras", "frutas"]:
            precios_base[pid] = np.random.uniform(800, 2500)
            rotacion_base[pid] = np.random.uniform(0.15, 0.35)  # Alta rotación
        elif producto_info["categoria"] in ["carnes", "congelados"]:
            precios_base[pid] = np.random.uniform(2500, 8000)
            rotacion_base[pid] = np.random.uniform(0.08, 0.20)
        else:
            precios_base[pid] = np.random.uniform(500, 3000)
            rotacion_base[pid] = np.random.uniform(0.05, 0.15)
    
    data['precio'] = data['producto_id'].map(precios_base)
    data['rotacion_base'] = data['producto_id'].map(rotacion_base)
    
    # 4. Efecto día de la semana (ventas altas fin de semana)
    efecto_dia = {1: 0.8, 2: 0.9, 3: 1.0, 4: 1.1, 5: 1.2, 6: 1.5, 7: 1.4}
    data['factor_dia'] = data['dia_semana'].map(efecto_dia)
    
    # 5. Efecto estacional (mes)
    # Temporada alta: Diciembre, Julio, Marzo (escolar)
    efecto_mes = {
        1: 0.9, 2: 0.95, 3: 1.1, 4: 1.0, 5: 0.95, 6: 0.9,
        7: 1.3, 8: 1.1, 9: 1.0, 10: 0.95, 11: 1.05, 12: 1.4
    }
    data['factor_mes'] = data['mes'].map(efecto_mes)
    
    # 6. Promociones (10% de los días, efecto variable)
    data['en_promocion'] = np.random.choice([0, 1], n_samples, p=[0.9, 0.1])
    data['descuento'] = np.where(
        data['en_promocion'] == 1,
        np.random.uniform(0.1, 0.3, n_samples),
        0
    )
    
    # 7. Temperatura (estacional)
    data['temperatura'] = 15 + 10 * np.sin(2 * np.pi * (data['mes'] - 1) / 12) + np.random.normal(0, 3, n_samples)
    
    # 8. Calcular ventas base con distribución real
    # Productos perecederos más sensibles a temperatura
    data['factor_temperatura'] = 1.0
    mascara_perecederos = data['producto_id'].apply(lambda x: catalogo_productos[x]['perecible'])
    data.loc[mascara_perecederos, 'factor_temperatura'] = 1 + (data.loc[mascara_perecederos, 'temperatura'] - 20) / 30
    
    # Ventas base con distribución log-normal (más realista)
    ventas_log_mean = np.log(30)  # Media logarítmica
    data['ventas_base_log'] = np.random.lognormal(
        ventas_log_mean, 
        0.5,  # Desviación
        n_samples
    )
    
    # Aplicar todos los factores
    data['ventas_diarias'] = np.round(
        data['ventas_base_log'] * 
        data['factor_dia'] * 
        data['factor_mes'] * 
        data['factor_temperatura'] * 
        (1 + data['en_promocion'] * 0.5)  # +50% en promoción
    ).clip(1, 150)  # Límites realistas
    
    # 9. Stock realista basado en ventas históricas
    # Stock = ventas promedio * cobertura_dias + stock_seguridad
    # Primero necesitamos calcular ventas promedio por producto
    ventas_promedio = data.groupby('producto_id')['ventas_diarias'].transform('mean')
    
    # Cobertura variable por categoría
    def calcular_cobertura(pid):
        cat = catalogo_productos[pid]['categoria']
        if cat in ["panaderia", "lacteos", "verduras", "frutas"]:
            return np.random.uniform(2, 5)  # Poco stock (alta rotación)
        elif cat in ["carnes", "congelados"]:
            return np.random.uniform(5, 10)
        else:
            return np.random.uniform(7, 15)
    
    data['dias_cobertura'] = data['producto_id'].apply(calcular_cobertura)
    data['stock_seguridad'] = ventas_promedio * np.random.uniform(0.5, 1.5, n_samples)
    
    data['stock_actual'] = np.round(
        ventas_promedio * data['dias_cobertura'] + data['stock_seguridad']
    ).clip(10, 500)  # Límites realistas
    
    # 10. Limpieza final
    columnas_finales = [
        'fecha', 'producto_id', 'ventas_diarias', 'stock_actual', 'precio',
        'en_promocion', 'descuento', 'temperatura', 'dia_semana', 'mes'
    ]
    
    data = data[columnas_finales].copy()
    data['nombre_producto'] = data['producto_id'].apply(lambda x: catalogo_productos[x]['nombre'])
    
    return data

# =============================================
# ANÁLISIS EXPLORATORIO AVANZADO
# =============================================

def analisis_exploratorio_avanzado(data):
    """Análisis exploratorio detallado con visualizaciones"""
    
    print("=" * 70)
    print("ANÁLISIS EXPLORATORIO AVANZADO")
    print("=" * 70)
    
    # 1. Estadísticas básicas
    print("\n📊 ESTADÍSTICAS BÁSICAS:")
    print(f"- Muestras totales: {len(data):,}")
    print(f"- Productos únicos: {data['producto_id'].nunique()}")
    print(f"- Período: {data['fecha'].min().date()} a {data['fecha'].max().date()}")
    
    # 2. Distribuciones
    fig, axes = plt.subplots(2, 3, figsize=(15, 10))
    
    # Ventas diarias
    axes[0, 0].hist(data['ventas_diarias'], bins=50, edgecolor='black', alpha=0.7)
    axes[0, 0].set_xlabel('Ventas Diarias (unidades)')
    axes[0, 0].set_ylabel('Frecuencia')
    axes[0, 0].set_title('Distribución de Ventas Diarias')
    axes[0, 0].axvline(data['ventas_diarias'].mean(), color='red', linestyle='--', label='Media')
    
    # Stock actual
    axes[0, 1].hist(data['stock_actual'], bins=50, edgecolor='black', alpha=0.7)
    axes[0, 1].set_xlabel('Stock Actual (unidades)')
    axes[0, 1].set_ylabel('Frecuencia')
    axes[0, 1].set_title('Distribución de Stock')
    axes[0, 1].axvline(data['stock_actual'].mean(), color='red', linestyle='--')
    
    # Precios
    axes[0, 2].hist(data['precio'], bins=50, edgecolor='black', alpha=0.7)
    axes[0, 2].set_xlabel('Precio ($)')
    axes[0, 2].set_ylabel('Frecuencia')
    axes[0, 2].set_title('Distribución de Precios')
    
    # Ventas por día de semana
    ventas_por_dia = data.groupby('dia_semana')['ventas_diarias'].mean()
    axes[1, 0].bar(range(1, 8), ventas_por_dia.values, alpha=0.7)
    axes[1, 0].set_xlabel('Día de la semana (1=Lunes)')
    axes[1, 0].set_ylabel('Ventas Promedio')
    axes[1, 0].set_title('Ventas por Día de la Semana')
    axes[1, 0].set_xticks(range(1, 8))
    
    # Ventas por mes
    ventas_por_mes = data.groupby('mes')['ventas_diarias'].mean()
    axes[1, 1].bar(range(1, 13), ventas_por_mes.values, alpha=0.7)
    axes[1, 1].set_xlabel('Mes')
    axes[1, 1].set_ylabel('Ventas Promedio')
    axes[1, 1].set_title('Ventas por Mes (Estacionalidad)')
    axes[1, 1].set_xticks(range(1, 13))
    
    # Relación Precio-Ventas
    scatter = axes[1, 2].scatter(data['precio'], data['ventas_diarias'], 
                                alpha=0.5, s=10, c=data['temperatura'], cmap='coolwarm')
    axes[1, 2].set_xlabel('Precio ($)')
    axes[1, 2].set_ylabel('Ventas Diarias')
    axes[1, 2].set_title('Relación Precio vs Ventas')
    plt.colorbar(scatter, ax=axes[1, 2], label='Temperatura (°C)')
    
    plt.tight_layout()
    plt.show()
    
    # 3. Correlaciones
    print("\n📈 MATRIZ DE CORRELACIONES:")
    numeric_cols = ['ventas_diarias', 'stock_actual', 'precio', 'temperatura', 
                    'en_promocion', 'descuento', 'dia_semana', 'mes']
    
    corr_matrix = data[numeric_cols].corr()
    
    plt.figure(figsize=(10, 8))
    sns.heatmap(corr_matrix, annot=True, cmap='coolwarm', center=0, 
                square=True, linewidths=1, cbar_kws={"shrink": 0.8})
    plt.title('Matriz de Correlaciones')
    plt.tight_layout()
    plt.show()
    
    print("\n🔍 CORRELACIONES CON VENTAS_DIARIAS:")
    print(corr_matrix['ventas_diarias'].sort_values(ascending=False).round(3))
    
    # 4. Análisis ABC (Pareto)
    print("\n📦 ANÁLISIS ABC (REGLA 80/20):")
    
    ventas_por_producto = data.groupby(['producto_id', 'nombre_producto']).agg({
        'ventas_diarias': 'sum',
        'precio': 'mean',
        'stock_actual': 'mean'
    }).reset_index()
    
    ventas_por_producto = ventas_por_producto.sort_values('ventas_diarias', ascending=False)
    ventas_por_producto['ventas_acum'] = ventas_por_producto['ventas_diarias'].cumsum()
    ventas_por_producto['porcentaje_acum'] = (ventas_por_producto['ventas_acum'] / 
                                              ventas_por_producto['ventas_diarias'].sum() * 100)
    
    # Clasificar ABC
    ventas_por_producto['categoria_abc'] = pd.cut(
        ventas_por_producto['porcentaje_acum'],
        bins=[0, 80, 95, 100],
        labels=['A', 'B', 'C']
    )
    
    abc_counts = ventas_por_producto['categoria_abc'].value_counts()
    print(f"\nDistribución ABC:")
    for cat in ['A', 'B', 'C']:
        count = abc_counts.get(cat, 0)
        productos_cat = ventas_por_producto[ventas_por_producto['categoria_abc'] == cat]
        porcentaje_ventas = productos_cat['ventas_diarias'].sum() / ventas_por_producto['ventas_diarias'].sum() * 100
        print(f"  Categoría {cat}: {count} productos ({porcentaje_ventas:.1f}% de ventas)")
    
    return ventas_por_producto

# =============================================
# PREPARACIÓN DE DATOS PARA MODELADO
# =============================================

def preparar_datos_modelado(data):
    """Prepara datos para modelado de ML"""
    
    # 1. Crear características adicionales
    data = data.copy()
    
    # Días de stock actual
    data['dias_stock_actual'] = data['stock_actual'] / data['ventas_diarias'].replace(0, 0.1)
    
    # Rotación actual
    data['rotacion_actual'] = data['ventas_diarias'] / data['stock_actual'].replace(0, 0.1)
    
    # Ventas promedio móvil (últimos 7 días)
    # Para esto necesitamos ordenar por fecha
    data = data.sort_values(['producto_id', 'fecha'])
    data['ventas_media_7d'] = data.groupby('producto_id')['ventas_diarias'].transform(
        lambda x: x.rolling(7, min_periods=1).mean()
    )
    
    # Diferencia día a día
    data['ventas_diff_1d'] = data.groupby('producto_id')['ventas_diarias'].diff().fillna(0)
    
    # 2. Codificación de variables categóricas
    data['fin_de_semana'] = data['dia_semana'].isin([6, 7]).astype(int)
    
    # 3. Variables para el modelo
    features = [
        'stock_actual',
        'precio',
        'en_promocion',
        'descuento',
        'temperatura',
        'dia_semana',
        'mes',
        'fin_de_semana',
        'dias_stock_actual',
        'rotacion_actual',
        'ventas_media_7d',
        'ventas_diff_1d'
    ]
    
    target = 'ventas_diarias'
    
    # 4. Split temporal (no aleatorio para series de tiempo)
    # Últimos 30 días para test
    cutoff_date = data['fecha'].max() - pd.Timedelta(days=30)
    train_data = data[data['fecha'] <= cutoff_date]
    test_data = data[data['fecha'] > cutoff_date]
    
    X_train = train_data[features]
    y_train = train_data[target]
    X_test = test_data[features]
    y_test = test_data[target]
    
    # 5. Escalado
    scaler = StandardScaler()
    X_train_scaled = scaler.fit_transform(X_train)
    X_test_scaled = scaler.transform(X_test)
    
    print(f"\n📐 PREPARACIÓN DE DATOS:")
    print(f"- Training: {len(X_train):,} muestras ({len(X_train)/len(data)*100:.1f}%)")
    print(f"- Testing: {len(X_test):,} muestras ({len(X_test)/len(data)*100:.1f}%)")
    print(f"- Features: {len(features)} variables")
    
    return X_train_scaled, X_test_scaled, y_train, y_test, scaler, features

# =============================================
# MODELADO DE REGRESIÓN AVANZADO
# =============================================

def modelado_regresion_avanzado(X_train, X_test, y_train, y_test):
    """Modelado avanzado con múltiples algoritmos y optimización"""
    
    print("\n" + "=" * 70)
    print("MODELADO DE REGRESIÓN AVANZADO")
    print("=" * 70)
    
    modelos = {}
    resultados = {}
    
    # 1. Regresión Lineal
    print("\n📈 1. REGRESIÓN LINEAL:")
    lr_model = LinearRegression()
    lr_model.fit(X_train, y_train)
    y_pred_lr = lr_model.predict(X_test)
    
    mae_lr = mean_absolute_error(y_test, y_pred_lr)
    rmse_lr = np.sqrt(mean_squared_error(y_test, y_pred_lr))
    r2_lr = r2_score(y_test, y_pred_lr)
    
    print(f"   MAE: {mae_lr:.2f}")
    print(f"   RMSE: {rmse_lr:.2f}")
    print(f"   R²: {r2_lr:.3f}")
    
    # 2. Random Forest con búsqueda de hiperparámetros
    print("\n🌲 2. RANDOM FOREST (optimizado):")
    
    # Hiperparámetros simplificados para velocidad
    param_grid_rf = {
        'n_estimators': [100, 200],
        'max_depth': [10, 20, None],
        'min_samples_split': [2, 5]
    }
    
    rf_model = RandomForestRegressor(random_state=Config.SEED, n_jobs=-1)
    grid_rf = GridSearchCV(rf_model, param_grid_rf, cv=3, scoring='neg_mean_absolute_error', n_jobs=-1)
    grid_rf.fit(X_train, y_train)
    
    rf_best = grid_rf.best_estimator_
    y_pred_rf = rf_best.predict(X_test)
    
    mae_rf = mean_absolute_error(y_test, y_pred_rf)
    rmse_rf = np.sqrt(mean_squared_error(y_test, y_pred_rf))
    r2_rf = r2_score(y_test, y_pred_rf)
    
    print(f"   Mejores parámetros: {grid_rf.best_params_}")
    print(f"   MAE: {mae_rf:.2f}")
    print(f"   RMSE: {rmse_rf:.2f}")
    print(f"   R²: {r2_rf:.3f}")
    
    # 3. Gradient Boosting
    print("\n🚀 3. GRADIENT BOOSTING:")
    gb_model = GradientBoostingRegressor(
        n_estimators=100,
        learning_rate=0.1,
        max_depth=4,
        random_state=Config.SEED
    )
    gb_model.fit(X_train, y_train)
    y_pred_gb = gb_model.predict(X_test)
    
    mae_gb = mean_absolute_error(y_test, y_pred_gb)
    rmse_gb = np.sqrt(mean_squared_error(y_test, y_pred_gb))
    r2_gb = r2_score(y_test, y_pred_gb)
    
    print(f"   MAE: {mae_gb:.2f}")
    print(f"   RMSE: {rmse_gb:.2f}")
    print(f"   R²: {r2_gb:.3f}")
    
    # 4. Selección del mejor modelo
    modelos_resultados = {
        'Linear Regression': {'model': lr_model, 'mae': mae_lr, 'rmse': rmse_lr, 'r2': r2_lr},
        'Random Forest': {'model': rf_best, 'mae': mae_rf, 'rmse': rmse_rf, 'r2': r2_rf},
        'Gradient Boosting': {'model': gb_model, 'mae': mae_gb, 'rmse': rmse_gb, 'r2': r2_gb}
    }
    
    mejor_modelo_nombre = min(modelos_resultados, key=lambda x: modelos_resultados[x]['mae'])
    mejor_modelo = modelos_resultados[mejor_modelo_nombre]
    
    print("\n🏆 MEJOR MODELO:")
    print(f"   {mejor_modelo_nombre}")
    print(f"   MAE: {mejor_modelo['mae']:.2f}")
    print(f"   Error relativo: {(mejor_modelo['mae']/y_test.mean()*100):.1f}%")
    
    # 5. Visualización de resultados
    fig, axes = plt.subplots(1, 3, figsize=(15, 5))
    
    # Comparación de MAE
    modelos_nombres = list(modelos_resultados.keys())
    maes = [modelos_resultados[m]['mae'] for m in modelos_nombres]
    
    bars = axes[0].bar(modelos_nombres, maes, color=['skyblue', 'lightgreen', 'salmon'])
    axes[0].set_ylabel('MAE (unidades)')
    axes[0].set_title('Comparación de Error Absoluto Medio (MAE)')
    axes[0].tick_params(axis='x', rotation=45)
    
    # Añadir valores en las barras
    for bar, mae in zip(bars, maes):
        height = bar.get_height()
        axes[0].text(bar.get_x() + bar.get_width()/2., height + 0.1,
                    f'{mae:.2f}', ha='center', va='bottom')
    
    # Predicciones vs Reales (mejor modelo)
    y_pred_best = mejor_modelo['model'].predict(X_test)
    axes[1].scatter(y_test, y_pred_best, alpha=0.5, s=20)
    axes[1].plot([y_test.min(), y_test.max()], [y_test.min(), y_test.max()], 'r--', lw=2)
    axes[1].set_xlabel('Ventas Reales')
    axes[1].set_ylabel('Ventas Predichas')
    axes[1].set_title(f'Predicciones vs Reales ({mejor_modelo_nombre})')
    axes[1].grid(True, alpha=0.3)
    
    # Distribución de errores
    errores = y_test - y_pred_best
    axes[2].hist(errores, bins=50, edgecolor='black', alpha=0.7)
    axes[2].axvline(x=0, color='red', linestyle='--', lw=2)
    axes[2].set_xlabel('Error (Real - Predicho)')
    axes[2].set_ylabel('Frecuencia')
    axes[2].set_title('Distribución de Errores del Mejor Modelo')
    
    plt.tight_layout()
    plt.show()
    
    return mejor_modelo, modelos_resultados

# =============================================
# CLUSTERING AVANZADO DE PRODUCTOS
# =============================================

def clustering_avanzado(data):
    """Clustering avanzado de productos"""
    
    print("\n" + "=" * 70)
    print("CLUSTERING AVANZADO DE PRODUCTOS")
    print("=" * 70)
    
    # 1. Preparar datos para clustering (agrupados por producto)
    producto_features = data.groupby(['producto_id', 'nombre_producto']).agg({
        'ventas_diarias': ['mean', 'std', 'sum'],
        'stock_actual': ['mean', 'std'],
        'precio': 'mean',
        'dias_stock_actual': 'mean',
        'rotacion_actual': 'mean'
    }).round(2)
    
    producto_features.columns = ['_'.join(col).strip() for col in producto_features.columns.values]
    producto_features = producto_features.reset_index()
    
    # 2. Normalización
    clustering_cols = [
        'ventas_diarias_mean',
        'ventas_diarias_std',
        'stock_actual_mean',
        'precio_mean',
        'rotacion_actual_mean'
    ]
    
    scaler_cluster = StandardScaler()
    cluster_data = producto_features[clustering_cols].copy()
    cluster_scaled = scaler_cluster.fit_transform(cluster_data)
    
    # 3. Determinación del número óptimo de clusters
    inertias = []
    silhouettes = []
    k_range = range(Config.N_CLUSTERS_MIN, Config.N_CLUSTERS_MAX + 1)
    
    for k in k_range:
        kmeans = KMeans(n_clusters=k, random_state=Config.SEED, n_init=10)
        labels = kmeans.fit_predict(cluster_scaled)
        inertias.append(kmeans.inertia_)
    
        try:
            score = silhouette_score(cluster_scaled, labels)
            silhouettes.append(score)
        except:
            silhouettes.append(0)

    
    # 4. Método del codo mejorado
    fig, axes = plt.subplots(1, 3, figsize=(15, 5))
    
    # Método del codo
    axes[0].plot(k_range, inertias, 'bo-')
    axes[0].set_xlabel('Número de Clusters')
    axes[0].set_ylabel('Inercia')
    axes[0].set_title('Método del Codo')
    axes[0].grid(True, alpha=0.3)
    
    # Silhouette score
    axes[1].plot(k_range[1:], silhouettes[1:], 'ro-')
    axes[1].set_xlabel('Número de Clusters')
    axes[1].set_ylabel('Silhouette Score')
    axes[1].set_title('Calidad de Clusters (Silhouette)')
    axes[1].grid(True, alpha=0.3)
    
    # Método combinado (gap statistic simplificado)
    gaps = []
    for i in range(1, len(inertias)):
        gaps.append(inertias[i-1] - inertias[i])
    
    if gaps:
        axes[2].plot(k_range[1:], gaps, 'go-')
        axes[2].set_xlabel('Número de Clusters')
        axes[2].set_ylabel('Reducción de Inercia')
        axes[2].set_title('Reducción Marginal de Inercia')
        axes[2].grid(True, alpha=0.3)
    
    plt.tight_layout()
    plt.show()
    
    # 5. Seleccionar k óptimo (máximo silhouette)
    k_optimo = k_range[1:][np.argmax(silhouettes[1:])]
    print(f"\n🔢 NÚMERO ÓPTIMO DE CLUSTERS: {k_optimo}")
    
    # 6. Aplicar clustering
    kmeans_final = KMeans(n_clusters=k_optimo, random_state=Config.SEED, n_init=10)
    producto_features['cluster'] = kmeans_final.fit_predict(cluster_scaled)
    
    # 7. Visualización PCA
    pca = PCA(n_components=2)
    cluster_pca = pca.fit_transform(cluster_scaled)
    
    producto_features['pca1'] = cluster_pca[:, 0]
    producto_features['pca2'] = cluster_pca[:, 1]
    
    plt.figure(figsize=(10, 8))
    scatter = plt.scatter(
        producto_features['pca1'],
        producto_features['pca2'],
        c=producto_features['cluster'],
        cmap='tab20',
        s=200,
        alpha=0.7,
        edgecolors='black'
    )
    
    # Añadir etiquetas
    for idx, row in producto_features.iterrows():
        plt.annotate(
            row['nombre_producto'][:10],  # Nombre truncado
            (row['pca1'], row['pca2']),
            fontsize=9,
            ha='center',
            va='center'
        )
    
    plt.xlabel(f'Componente Principal 1 ({pca.explained_variance_ratio_[0]*100:.1f}%)')
    plt.ylabel(f'Componente Principal 2 ({pca.explained_variance_ratio_[1]*100:.1f}%)')
    plt.title(f'Clustering de Productos (k={k_optimo})')
    plt.colorbar(scatter, label='Cluster')
    plt.grid(True, alpha=0.3)
    plt.tight_layout()
    plt.show()
    
    # 8. Análisis de clusters
    print("\n📊 ANÁLISIS DE CLUSTERS:")
    
    cluster_summary = producto_features.groupby('cluster').agg({
        'nombre_producto': lambda x: ', '.join(x.tolist()),
        'ventas_diarias_mean': 'mean',
        'stock_actual_mean': 'mean',
        'precio_mean': 'mean',
        'rotacion_actual_mean': 'mean',
        'producto_id': 'count'
    }).round(2)
    
    cluster_summary = cluster_summary.rename(columns={'producto_id': 'n_productos'})
    
    print("\nResumen por Cluster:")
    print(cluster_summary.to_string())
    
    # 9. Perfiles de clusters
    print("\n👥 PERFILES DE CLUSTERS IDENTIFICADOS:")
    
    for cluster_id in range(k_optimo):
        cluster_data = producto_features[producto_features['cluster'] == cluster_id]
        
        # Determinar perfil
        precio_prom = cluster_data['precio_mean'].mean()
        ventas_prom = cluster_data['ventas_diarias_mean'].mean()
        rotacion_prom = cluster_data['rotacion_actual_mean'].mean()
        
        if precio_prom > producto_features['precio_mean'].mean():
            precio_cat = "ALTO"
        else:
            precio_cat = "BAJO/MEDIO"
            
        if ventas_prom > producto_features['ventas_diarias_mean'].mean():
            ventas_cat = "ALTA"
        else:
            ventas_cat = "BAJA"
            
        if rotacion_prom > producto_features['rotacion_actual_mean'].mean():
            rotacion_cat = "ALTA"
        else:
            rotacion_cat = "BAJA"
        
        productos = cluster_data['nombre_producto'].tolist()
        
        print(f"\nCluster {cluster_id}:")
        print(f"  - Perfil: Precio {precio_cat}, Ventas {ventas_cat}, Rotación {rotacion_cat}")
        print(f"  - Productos ({len(productos)}): {', '.join(productos[:5])}{'...' if len(productos) > 5 else ''}")
    
    return producto_features, cluster_summary

def agregar_metricas_inventario(data):
    """
    Agrega métricas básicas de inventario necesarias para clustering
    SIN alterar la lógica existente del sistema
    """
    data = data.copy()

    if 'dias_stock_actual' not in data.columns:
        data['dias_stock_actual'] = (
            data['stock_actual'] / data['ventas_diarias'].replace(0, 0.1)
        )

    if 'rotacion_actual' not in data.columns:
        data['rotacion_actual'] = (
            data['ventas_diarias'] / data['stock_actual'].replace(0, 0.1)
        )

    return data


# =============================================
# SISTEMA DE ALERTAS INTELIGENTE
# =============================================

def sistema_alertas_inteligente(data, producto_features, mejor_modelo, features, scaler):
    """Sistema avanzado de alertas de inventario"""
    
    print("\n" + "=" * 70)
    print("SISTEMA DE ALERTAS INTELIGENTE DE INVENTARIO")
    print("=" * 70)
    
    # 1. Preparar datos para predicción
    data_alerts = data.copy()
    
    # Calcular características para alertas
    data_alerts['dias_stock_actual'] = data_alerts['stock_actual'] / data_alerts['ventas_diarias'].replace(0, 0.1)
    
    # Ventas promedio últimos 7 días
    data_alerts = data_alerts.sort_values(['producto_id', 'fecha'])
    data_alerts['ventas_media_7d'] = data_alerts.groupby('producto_id')['ventas_diarias'].transform(
        lambda x: x.rolling(7, min_periods=1).mean()
        
    )
    data_alerts['ventas_diff_1d'] = data_alerts.groupby('producto_id')['ventas_diarias'].diff().fillna(0)

    
    # 2. Predecir ventas futuras (próximos 7 días)
    # Preparar features para predicción
    features_alerts = [
        'stock_actual',
        'precio',
        'en_promocion',
        'descuento',
        'temperatura',
        'dia_semana',
        'mes',
        'fin_de_semana',
        'dias_stock_actual',
        'rotacion_actual',
        'ventas_media_7d',
        'ventas_diff_1d'
    ]
    
    # Asegurar que todas las features estén presentes
    for feat in features_alerts:
        if feat not in data_alerts.columns:
            if feat == 'fin_de_semana':
                data_alerts['fin_de_semana'] = data_alerts['dia_semana'].isin([6, 7]).astype(int)
            elif feat == 'rotacion_actual':
                data_alerts['rotacion_actual'] = data_alerts['ventas_diarias'] / data_alerts['stock_actual'].replace(0, 0.1)
    
    X_alerts = data_alerts[features_alerts]
    X_alerts_scaled = scaler.transform(X_alerts)
    
    # Predecir
    data_alerts['ventas_predichas'] = mejor_modelo['model'].predict(X_alerts_scaled)
    
    # 3. Calcular métricas de inventario
    data_alerts['dias_stock_proyectado'] = data_alerts['stock_actual'] / data_alerts['ventas_predichas'].replace(0, 0.1)
    
    # 4. Sistema de alertas por percentiles y reglas de negocio
    def clasificar_alerta(row):
        dias_stock = row['dias_stock_proyectado']
        producto_id = row['producto_id']
        
        # Obtener información del producto
        producto_info = catalogo_productos[producto_id]
        es_perecedero = producto_info['perecible']
        
        # Reglas basadas en tipo de producto
        if es_perecedero:
            # Productos perecederos: menos días de stock aceptables
            if dias_stock < 2:
                return "CRÍTICO"
            elif dias_stock < 4:
                return "ALTO"
            elif dias_stock > 10:
                return "EXCESO"
            else:
                return "NORMAL"
        else:
            # Productos no perecederos
            if dias_stock < 5:
                return "CRÍTICO"
            elif dias_stock < 8:
                return "ALTO"
            elif dias_stock > 30:
                return "EXCESO"
            else:
                return "NORMAL"
    
    data_alerts['nivel_alerta'] = data_alerts.apply(clasificar_alerta, axis=1)
    
    # 5. Dashboard de alertas
    print("\n📋 DASHBOARD DE ALERTAS:")
    
    # Resumen por nivel de alerta
    alert_summary = data_alerts.groupby('nivel_alerta').agg({
        'producto_id': 'nunique',
        'dias_stock_proyectado': ['mean', 'min', 'max']
    }).round(2)
    
    alert_summary.columns = ['n_productos', 'dias_promedio', 'dias_min', 'dias_max']
    print(alert_summary)
    
    # 6. Productos críticos (top 10)
    productos_criticos = data_alerts[data_alerts['nivel_alerta'] == 'CRÍTICO']
    
    if not productos_criticos.empty:
        productos_criticos_agg = productos_criticos.groupby(['producto_id', 'nombre_producto']).agg({
            'dias_stock_proyectado': 'min',
            'stock_actual': 'mean',
            'ventas_predichas': 'mean'
        }).round(2).reset_index()
        
        productos_criticos_agg = productos_criticos_agg.sort_values('dias_stock_proyectado').head(10)
        
        print("\n🚨 TOP 10 PRODUCTOS CRÍTICOS (requieren acción inmediata):")
        print("-" * 70)
        for idx, row in productos_criticos_agg.iterrows():
            print(f"{row['nombre_producto']}: {row['dias_stock_proyectado']:.1f} días de stock | "
                  f"Stock: {row['stock_actual']:.0f} | "
                  f"Ventas predichas: {row['ventas_predichas']:.1f}/día")
    else:
        print("\n✅ No hay productos en estado CRÍTICO")
    
    # 7. Productos con exceso de stock
    productos_exceso = data_alerts[data_alerts['nivel_alerta'] == 'EXCESO']
    
    if not productos_exceso.empty:
        productos_exceso_agg = productos_exceso.groupby(['producto_id', 'nombre_producto']).agg({
            'dias_stock_proyectado': 'max',
            'stock_actual': 'mean',
            'ventas_predichas': 'mean'
        }).round(2).reset_index()
        
        productos_exceso_agg = productos_exceso_agg.sort_values('dias_stock_proyectado', ascending=False).head(10)
        
        print("\n📦 TOP 10 PRODUCTOS CON EXCESO DE STOCK:")
        print("-" * 70)
        for idx, row in productos_exceso_agg.iterrows():
            print(f"{row['nombre_producto']}: {row['dias_stock_proyectado']:.1f} días de stock | "
                  f"Stock: {row['stock_actual']:.0f} | "
                  f"Ventas predichas: {row['ventas_predichas']:.1f}/día")
    
    return data_alerts, alert_summary

# =============================================
# MÉTRICAS DE NEGOCIO Y RECOMENDACIONES
# =============================================

def metricas_negocio_y_recomendaciones(data, producto_features, data_alerts):
    """Calcula métricas de negocio y genera recomendaciones"""
    
    print("\n" + "=" * 70)
    print("MÉTRICAS DE NEGOCIO Y RECOMENDACIONES")
    print("=" * 70)
    
    # 1. Métricas clave
    inventario_total = data['stock_actual'].sum()
    valor_inventario = (data['stock_actual'] * data['precio']).sum()
    ventas_totales = data['ventas_diarias'].sum()
    valor_ventas = (data['ventas_diarias'] * data['precio']).sum()
    
    # Rotación real
    rotacion_anual = (ventas_totales * 365) / inventario_total if inventario_total > 0 else 0
    
    # Cobertura promedio
    cobertura_promedio = data['stock_actual'].sum() / data['ventas_diarias'].sum() if data['ventas_diarias'].sum() > 0 else 0
    
    print("\n📊 MÉTRICAS PRINCIPALES:")
    print(f"- Inventario total: {inventario_total:,.0f} unidades")
    print(f"- Valor del inventario: ${valor_inventario:,.0f}")
    print(f"- Ventas diarias promedio: {ventas_totales/len(data):.1f} unidades")
    print(f"- Rotación anual: {rotacion_anual:.1f} veces")
    print(f"- Cobertura promedio: {cobertura_promedio:.1f} días")
    
    # 2. Análisis por categoría ABC
    print("\n🎯 ANÁLISIS POR CATEGORÍA ABC:")
    
    # Calcular valor por producto
    producto_valor = data.groupby(['producto_id', 'nombre_producto']).agg({
        'ventas_diarias': 'sum',
        'stock_actual': 'mean',
        'precio': 'mean'
    }).reset_index()
    
    producto_valor['valor_ventas'] = producto_valor['ventas_diarias'] * producto_valor['precio']
    producto_valor = producto_valor.sort_values('valor_ventas', ascending=False)
    
    # Clasificar ABC
    producto_valor['ventas_acum'] = producto_valor['valor_ventas'].cumsum()
    producto_valor['porcentaje_acum'] = producto_valor['ventas_acum'] / producto_valor['valor_ventas'].sum() * 100
    producto_valor['categoria_abc'] = pd.cut(
        producto_valor['porcentaje_acum'],
        bins=[0, 80, 95, 100],
        labels=['A', 'B', 'C']
    )
    
    abc_summary = producto_valor.groupby('categoria_abc').agg({
        'producto_id': 'count',
        'valor_ventas': 'sum',
        'stock_actual': 'mean'
    })
    
    print("\nDistribución ABC (Pareto):")
    for categoria in ['A', 'B', 'C']:
        cat_data = abc_summary.loc[categoria] if categoria in abc_summary.index else None
        if cat_data is not None:
            print(f"  Categoría {categoria}: {int(cat_data['producto_id'])} productos "
                  f"({cat_data['valor_ventas']/producto_valor['valor_ventas'].sum()*100:.1f}% del valor)")
    
    # 3. Recomendaciones específicas
    print("\n💡 RECOMENDACIONES OPERATIVAS:")
    
    # A. Recomendaciones para productos críticos
    productos_criticos = data_alerts[data_alerts['nivel_alerta'] == 'CRÍTICO']
    if not productos_criticos.empty:
        productos_criticos_list = productos_criticos['nombre_producto'].unique()[:5]
        print("\n1. ACCIONES INMEDIATAS (productos críticos):")
        print("   • Crear órdenes de compra URGENTES para:")
        for producto in productos_criticos_list:
            print(f"     - {producto}")
        print("   • Nivel objetivo: mínimo 5 días de stock")
    
    # B. Optimización de inventario
    productos_exceso = data_alerts[data_alerts['nivel_alerta'] == 'EXCESO']
    if not productos_exceso.empty:
        productos_exceso_list = productos_exceso['nombre_producto'].unique()[:5]
        print("\n2. OPTIMIZACIÓN DE INVENTARIO:")
        print("   • Considerar promociones o descuentos para:")
        for producto in productos_exceso_list:
            print(f"     - {producto}")
        print("   • Revisar políticas de compra para estos productos")
    
    # C. Recomendaciones por categoría ABC
    print("\n3. ESTRATEGIA POR CATEGORÍA ABC:")
    print("   • Categoría A (alto valor): Monitoreo diario, stock 3-7 días")
    print("   • Categoría B (valor medio): Monitoreo semanal, stock 7-14 días")
    print("   • Categoría C (bajo valor): Monitoreo mensual, stock 14-30 días")
    
    # D. Recomendaciones generales
    print("\n4. MEJORAS SISTÉMICAS:")
    print("   • Implementar sistema de pronóstico automático")
    print("   • Establecer niveles de stock por categoría de producto")
    print("   • Crear alertas automáticas por producto")
    print("   • Revisar semanalmente clasificación ABC")
    
    # 4. ROI potencial
    print("\n💰 IMPACTO FINANCIERO ESPERADO:")
    
    # Estimación de mejora
    mejora_rotacion = min(20, max(5, 30 - rotacion_anual))  # Mejora del 5-20%
    ahorro_inventario = valor_inventario * (mejora_rotacion / 100)
    
    print(f"- Rotación actual: {rotacion_anual:.1f} veces/año")
    print(f"- Objetivo: {rotacion_anual + mejora_rotacion:.1f} veces/año (+{mejora_rotacion:.0f}%)")
    print(f"- Reducción potencial de inventario: ${ahorro_inventario:,.0f}")
    print(f"- Liberación de capital de trabajo: ~${ahorro_inventario*0.7:,.0f}")
    
    return producto_valor

# =============================================
# FUNCIÓN PRINCIPAL
# =============================================

def main():
    """Función principal que ejecuta todo el pipeline"""
    
    print("=" * 80)
    print("SISTEMA DE GESTIÓN DE INVENTARIO - SUPERMERCADO GO")
    print("=" * 80)
    
    # 1. Generar datos
    print("\n📁 GENERANDO DATOS REALISTAS...")
    data = generar_datos_realistas()
    
    # 2. Análisis exploratorio
    ventas_por_producto = analisis_exploratorio_avanzado(data)
    
    # 3. Preparar datos para modelado
    X_train, X_test, y_train, y_test, scaler, features = preparar_datos_modelado(data)
    
    # 4. Modelado de regresión
    mejor_modelo, todos_modelos = modelado_regresion_avanzado(X_train, X_test, y_train, y_test)
    
    # 5. Clustering de productos
    producto_features, cluster_summary = clustering_avanzado(agregar_metricas_inventario(data))
    
    # 6. Sistema de alertas
    data_alerts, alert_summary = sistema_alertas_inteligente(
        data, producto_features, mejor_modelo, features, scaler
    )
    
    # 7. Métricas de negocio y recomendaciones
    producto_valor = metricas_negocio_y_recomendaciones(data, producto_features, data_alerts)
    
    # 8. Exportar resultados
    print("\n💾 EXPORTANDO RESULTADOS...")
    
    # Crear carpeta para resultados
    import os
    os.makedirs('resultados', exist_ok=True)
    
    # Exportar datos principales
    data.to_csv('resultados/datos_completos.csv', index=False)
    producto_features.to_csv('resultados/clustering_productos.csv', index=False)
    data_alerts.to_csv('resultados/alertas_inventario.csv', index=False)
    
    # Exportar resumen ejecutivo
    with open('resultados/resumen_ejecutivo.txt', 'w', encoding="utf-8") as f:
        f.write("RESUMEN EJECUTIVO - SISTEMA DE GESTIÓN DE INVENTARIO\n")
        f.write("=" * 60 + "\n\n")
        
        f.write("📊 MÉTRICAS PRINCIPALES:\n")
        f.write(f"- Productos analizados: {data['producto_id'].nunique()}\n")
        f.write(f"- Período: {data['fecha'].min().date()} a {data['fecha'].max().date()}\n")
        f.write(f"- Ventas totales: {data['ventas_diarias'].sum():,.0f} unidades\n")
        f.write(f"- Stock total: {data['stock_actual'].sum():,.0f} unidades\n")
        f.write(f"- Rotación anual: {(data['ventas_diarias'].sum() * 365 / data['stock_actual'].sum()):.1f}\n\n")
        
        f.write("🎯 MODELO DE PREDICCIÓN:\n")
        f.write(f"- Mejor modelo: {list(todos_modelos.keys())[np.argmin([m['mae'] for m in todos_modelos.values()])]}\n")
        f.write(f"- MAE: {min([m['mae'] for m in todos_modelos.values()]):.2f}\n")
        f.write(f"- Error relativo: {(min([m['mae'] for m in todos_modelos.values()])/y_test.mean()*100):.1f}%\n\n")
        
        f.write("🚨 ALERTAS ACTUALES:\n")
        for nivel in alert_summary.index:
            f.write(f"- {nivel}: {int(alert_summary.loc[nivel, 'n_productos'])} productos\n")
        
        f.write("\n💡 RECOMENDACIONES PRIORITARIAS:\n")
        
        # Obtener productos críticos
        productos_criticos = data_alerts[data_alerts['nivel_alerta'] == 'CRÍTICO']
        if not productos_criticos.empty:
            top_criticos = productos_criticos['nombre_producto'].unique()[:3]
            f.write("1. Reabastecer urgentemente:\n")
            for prod in top_criticos:
                f.write(f"   • {prod}\n")
    
    print("\n✅ PROCESO COMPLETADO CON ÉXITO!")
    print("📁 Resultados guardados en carpeta 'resultados/'")
    
    return {
        'data': data,
        'modelo': mejor_modelo,
        'producto_features': producto_features,
        'data_alerts': data_alerts,
        'producto_valor': producto_valor
    }

# =============================================
# EJECUCIÓN
# =============================================

if __name__ == "__main__":
    try:
        resultados = main()
        
        print("\n" + "=" * 80)
        print("🎉 ANÁLISIS COMPLETADO EXITOSAMENTE!")
        print("=" * 80)
        
        # Resumen final
        print("\n📋 RESUMEN FINAL:")
        print(f"• Datos procesados: {len(resultados['data']):,} registros")
        print(f"• Modelo implementado: MAE = {resultados['modelo']['mae']:.2f}")
        print(f"• Productos clusterizados: {len(resultados['producto_features'])}")
        print(f"• Alertas generadas: {len(resultados['data_alerts'])}")
        
        print("\n🚀 Próximos pasos recomendados:")
        print("1. Revisar archivos en carpeta 'resultados/'")
        print("2. Implementar alertas críticas en sistema operativo")
        print("3. Monitorear métricas semanalmente")
        print("4. Ajustar parámetros según feedback operacional")
        
    except Exception as e:
        print(f"\n❌ ERROR: {str(e)}")
        import traceback
        traceback.print_exc()